int main(void){
clear_OLED();
print_message("EmbeddedCentric",0);
print_message("  ZedboardOLED",2);
print_message("By: Ali Aljaani",3);
return (1);
}

